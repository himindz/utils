#!/bin/bash

trap shutdown SIGTERM SIGINT
/usr/sbin/sshd -D
