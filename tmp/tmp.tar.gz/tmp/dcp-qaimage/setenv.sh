#! /bin/sh
export JPDA_ADDRESS="8000"

