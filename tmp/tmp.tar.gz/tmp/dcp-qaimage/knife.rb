log_level                :info
log_location             STDOUT
node_name                'alikhan'
client_key               '/home/jenkins/.chef/jenkins-docker.pem'
validation_client_name   'aib-validator'
validation_key           '/home/jenkins/.chef/aib-validator.pem'
chef_server_url          'https://rhethalt2.mid.aib.pri/organizations/aib'
syntax_check_cache_path  '/home/jenkins/.chef/syntax_check_cache'
trusted_certs_dir 	 '/home/jenkins/.chef/trusted_certs'
cookbook_path [ '.', '..', './cookbooks', '~/git/chef' ]
