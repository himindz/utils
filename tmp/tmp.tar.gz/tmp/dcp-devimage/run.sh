#!/bin/bash
docker run -d -p 8080:8080 -p 50000:50000 -v /var/jenkins_home:/var/jenkins_home --env GIT_SSL_NO_VERIFY=1 --env JAVA_OPTS="-Dhudson.model.DirectoryBrowserSupport.CSP=  -Dhttp.proxyHost=webproxy.ad.aib.pri -Dhttp.proxyPort=8080 -Dhttp.nonProxyHosts=\"10.0.2.4|localhost|192.168.99.1|192.168.56.1|192.168.*.*|127.0.0.1|10.*.*.*|*.aib.pri\" " devimage
